from django.contrib import admin
from enderecos.models import Endereco

admin.site.register(Endereco)
