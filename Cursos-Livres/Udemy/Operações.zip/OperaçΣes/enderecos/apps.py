from django.apps import AppConfig


class EnderecosConfig(AppConfig):
    name = 'enderecos'
