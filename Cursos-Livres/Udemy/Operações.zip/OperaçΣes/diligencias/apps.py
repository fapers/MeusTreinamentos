from django.apps import AppConfig


class DiligenciasConfig(AppConfig):
    name = 'diligencias'
