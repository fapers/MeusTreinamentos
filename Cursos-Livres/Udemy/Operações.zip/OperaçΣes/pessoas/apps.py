from django.apps import AppConfig


class PessoasConfig(AppConfig):
    name = 'pessoas'
