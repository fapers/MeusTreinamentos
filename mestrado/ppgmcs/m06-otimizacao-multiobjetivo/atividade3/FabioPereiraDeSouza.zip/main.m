clear all; % Limpa todas as variáveis
close all; % Fecha todas figuras
clc; % Limpa a tela

% Espaço de busca
xmin = -100;
xmax = 100;

% Número de execuções do algoritmo
numEXEC = 10;

% Problema a ser abordado
problema = 1;

% Operador de cruzamento utilizado
metCRUZ = -1;
while metCRUZ < 1 || metCRUZ > 3
   clc;
   prompt = "Entre com o método de cruzamento: ";
   metCRUZ = input(prompt);
end

% Operador de mutação utilizado
metMUT = -1;
while metMUT < 1 || metMUT > 3
    prompt = "Entre com o método de mutação: ";
    metMUT = input(prompt);
end

% Operador de seleção utilizado
metSEL = 1;

% Número de variáveis do problema
numVAR = 1;

% Critério de parada
maxFX = 1000;

% Tamanho da população
tamPOP = 20;

% Armazenando os melhores resultados
melhor = xmax^2 * rand(1, numEXEC) + 10000;
pior = 0 * rand(1, numEXEC);

subplot(1,2,1);
X = xmin:xmax;
Y = X.^2;
plot(X, Y);

for t = 1:numEXEC
    tempo = cputime();
    
    % Geração da população inicial aleatória
    POP = xmin + rand(tamPOP,numVAR) .* (xmax - xmin);
    FX = calculaFX(POP,problema);
    
    % Número de soluções geradas até o momento
    numFX = tamPOP;
    
    hold on
    
    while numFX < maxFX 
        % O parâmetro metCRUZ deve definir o operador a ser utilizado
        POPnovo = cruzamento(POP,xmin,xmax,metCRUZ);
        
        % A mutação ocorre na população gerada, mas isso pode ser alterado
        POPnovo = mutacao(POPnovo,xmin,xmax,metMUT);
        
        FXnovo = calculaFX(POPnovo,problema);
        numFX = numFX + size(POPnovo,1);
        
        POP = [POP; POPnovo];
        FX = [FX; FXnovo];
        
        % O parâmetro metSEL será utilizado posteriormente
        [POP, FX] = selecao(POP,FX,tamPOP,metSEL);        
        
        plot(POP, FX, 'd')
        
    end
    hold off    
    tempo = cputime() - tempo; 
    
    menor = min(FX(:));
    maior = max(FX(:));
    
    fprintf('O melhor valor encontrado foi: %2.4f & \t\t(%1.4f segundos)\\\\ \n',menor,tempo);
%     fprintf('O pior valor encontrado foi: %2.4f \t\t(%1.4f segundos)\n',maior,tempo);
    if(melhor(t) > menor)
        melhor(t) = menor;
    end
    
    if(pior(t) < maior)
        pior(t) = maior; 
    end
end
title('Evolução da Função Objetivo');
xlabel('Intervalo xmin e xmax');
ylabel('FX');
legend('Espaço de busca','Evolução');
grid on;


% [X,Y] = meshgrid(xmin:10:xmax);
% Z = X.^2;
% subplot(2,2,1); 
% surf(X,Y,Z);
% %mesh(X,Y,Z);
% axis square;
% rotate3d on;
% shading interp;
% colormap winter;
% title('Espaço de Busca da Função F(x) = x^2 no intervalo -100 a 100');
% legend('Espaço de busca','Location', 'southoutside');
% zlabel('FX');

% X = xmin:xmax;
% Y = X.^2;

subplot(2,2,2);
plot(1:10,melhor,'b*');
legend('Melhores FX');
title('Resultado do Algoritmo Genético');
xlabel('Execuções');
ylabel('Resultados');
grid on;

subplot(2,2,4);
plot(1:10,pior,'r*');
legend('Piores FX');
title('Resultado do Algoritmo Genético');
xlabel('Execuções');
ylabel('Resultados');
grid on;