function POPnovo = cruzamento(POP,xmin,xmax,metCRUZ)
    % Apenas para auxílio, caso necessário
    [tamPOP, numVAR] = size(POP);
    r1 = randperm(tamPOP);
    r2 = randperm(tamPOP);
    
    switch metCRUZ
        case 1 % média: 
               % (x1 + x2) /2
               POPnovo = (POP(r1,:) + POP(r2,:)) / 2;
            
        case 2 % valor aleatório entre x1 e x2: 
               % x1 + (rand * (x2 - x1))
               POPnovo = POP(r1,:) + (rand .* (POP(r2,:) - POP(r1,:)));
            
        case 3 % valor aleatório que extrapola o intervalo entre x1 e x2
               % x1 + (2 * rand - 1) * (x2 - x1)
               POPnovo = POP(r1,:) + (2 * rand - 1) .* (POP(r2,:) - POP(r1,:));
               
        otherwise
            fprintf('MÉTODO DE CRUZAMENTO NÃO IMPLEMENTADO');
    end
    
    % Para garantir que a nova população não extrapole o espaco de busca
    POPnovo = max(POPnovo,xmin);
    POPnovo = min(POPnovo,xmax);
end