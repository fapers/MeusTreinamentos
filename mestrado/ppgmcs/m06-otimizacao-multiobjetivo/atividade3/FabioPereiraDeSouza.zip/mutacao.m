function POPnovo = mutacao(POP,xmin,xmax,metMUT)
    % Apenas para auxílio, caso necessário
    [tamPOP, numVAR] = size(POP);
    r1 = randperm(tamPOP);
    
    switch metMUT
        case 1 % valor aleatório até 50% do espaço de busca
               % x1 + (rand - 0,5) * (xmax - xmin)
               POPnovo = POP(r1,:) + (rand - 0.5) .* (xmax - xmin);
            
        case 2 % valor aleatório até 50% do valor de C
               % x1 + (rand - 0,5) * C
               C = 0.0001; % altere o valor de C
               POPnovo = POP(r1,:) + (rand - 0.5) * C;
            
        case 3 % valor aleatório
               % xmin + rand * (xmax - xmin)
               POPnovo = xmin + rand(tamPOP,numVAR) .* (xmax - xmin);
               
        otherwise
            fprintf('MÉTODO DE MUTAÇÃO NÃO IMPLEMENTADO');
    end
    
    % Para garantir que a nova população não extrapole o espaco de busca
    POPnovo = max(POPnovo,xmin);
    POPnovo = min(POPnovo,xmax);    
end