function POPn = processoevolutivo(POP,xmin,xmax)

    [numPOP,numVAR] = size(POP);
    
%     n = 10;
%     pMUT = 0.2;
    n = 100;
    pMUT = 0.02;
    
    POPn = zeros(numPOP,numVAR);
    
    for i = 1:numPOP
        P = randperm(numPOP);        
        u = rand;

        if (u <= 0.5)
%         if (u <= 0.99)
            B = (2*u) ^ (1 / (n+1));
        else
            B = (1/(2*(1-u))) ^ (1/(n+1));
        end

        if (rand <= 0.5)
%         if (rand <= 0.01)
            POPn(i,:) = 0.5 * ((1 + B) * POP(P(1),:) + (1 - B) * POP(P(2),:));
        else
            POPn(i,:) = 0.5 * ((1 - B) * POP(P(1),:) + (1 + B) * POP(P(2),:));
        end

        for d = 1:numVAR
            if (rand <= pMUT)
                POPn(i,d) = POPn(i,d) + (rand - 0.5) .* (xmax(d) - xmin(d));
%                 POPn(i,d) = POPn(i,d) + 0.5 * (rand - 0.5) .* (xmax(d) - xmin(d));
            end
        end
        POPn(i,:) = min(POPn(i,:),xmax);
        POPn(i,:) = max(POPn(i,:),xmin);        
    end
end