function ind = sorting(FX,numPOP)
    
    [tamPOP, numOBJ] = size(FX);
    
    S = cell(tamPOP,1);
    N = zeros(tamPOP,1);
    
    ind = [];
    
    for i = 1:tamPOP-1        
        for j = i+1:tamPOP
            cont = 0;
            for d = 1:numOBJ
                if (FX(i,d) <= FX(j,d))
                    cont = cont + 1;
                end                
            end
            if (cont == numOBJ)
                S{i}(end+1) = j;
                N(j) = N(j) + 1;
            else
                if (cont == 0)
                    S{j}(end+1) = i;
                    N(i) = N(i) + 1;
                end
            end            
        end
    end
    
    while (length(ind) < numPOP)
        indE = find(N == 0);
        N(indE) = -1;
        for i = 1:length(indE)
            for j = 1:length(S{indE(i)})
                N(S{indE(i)}(j)) = N(S{indE(i)}(j)) - 1;
            end
        end
        if (length(ind) + length(indE) > numPOP)
            iAUX = crowding(FX(indE,:));
            indE = indE(iAUX);
        end
        ind = [ind; indE];
    end
    ind = ind(1:numPOP);
end


function ind = crowding(FX)

    numOBJ = size(FX,2);

    FXmin = min(FX,[],2);
    FXmax = max(FX,[],2);

    numPOP = size(FX,1);

    dist(1:numPOP) = 0;

    for d = randperm(numOBJ)
        [~, ind] = sortrows(FX,d);
        dist(ind(1)) = inf;
        dist(ind(end)) = inf;

        for j = 2:numPOP-1
            dist(ind(j)) = dist(ind(j)) + (FX(ind(j+1),d)-FX(ind(j-1),d))/(FXmax(d)-FXmin(d));
       end
    end

    [~,ind] = sort(dist,2,'descend');
end