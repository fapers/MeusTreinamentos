function [POP, FX] = NSGAII(problema,numOBJ,maxFX)
%     addpath('..','../data','../results');
    addpath('..','../data','../results');
    GRAFICO = 0;

    V = initVET(numOBJ);
    numPOP = size(V,1);
    
    numFX = 0;
    [numVAR, ~, ~, xmin, xmax, numOBJ,PF] = limites(problema,numOBJ,1);
    
    POP = repmat(xmin,numPOP,1) + rand(numPOP,numVAR) .* repmat(xmax-xmin,numPOP,1);
    FX = calculaFX(POP,problema,numOBJ,1);
    numFX = numFX + size(POP,1);
    
    cont = 0;
    while (numFX < maxFX)
        POPn = processoevolutivo(POP,xmin,xmax);
        FXn = calculaFX(POPn,problema,numOBJ,1);
        numFX = numFX + size(POPn,1);
        POP = [POP; POPn];
        FX = [FX; FXn];
        
        ind = sorting(FX,numPOP);
        
        POP = POP(ind,:);
        FX = FX(ind,:);
        
        if ((GRAFICO == 1) && (numFX/1000 >= cont))
            cont = cont + 1;
%             subplot(2,1,1);
            switch numOBJ
                case 2
                    hold off;
                    plot(PF(:,1),PF(:,2),'k.');                    
                    hold on;
                    plot(FX(:,1),FX(:,2),'ro');
                    axis(1 * [0 1 0 1]);
                    grid on;
                case 3
                    plot3(FX(:,1),FX(:,2),FX(:,3),'b.');
%                     axis(1 * [0 1 0 1 0 1]);
                    view([60 10]);
                otherwise
                    parallelcoords(FX);
            end
            grid on;
            xlabel([num2str(numFX) ' (' num2str(maxFX) ') - ' num2str(size(FX,1))]);

%             subplot(2,1,2);
%             parallelcoords(POP);
%             grid on;
            drawnow();
        end
        
    end
end