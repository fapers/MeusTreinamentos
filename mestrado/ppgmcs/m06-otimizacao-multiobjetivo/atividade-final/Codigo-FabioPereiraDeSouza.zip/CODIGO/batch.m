function batch(problema,numOBJ,metodo,numEXEC)
    IGD = [];
    for n = 1:length(numOBJ)
        for p = 1:length(problema)
            prob = problema{p};
            
            [~, ~, maxFX, ~, ~, nOBJ,PF] = limites(prob,numOBJ(n),1);
            NADIR = max(PF);
            for t = 1:numEXEC
                for i = 1:length(metodo)
                    T = cputime();
                    F = str2func(metodo{i});
                    cd(metodo{i});
                    [POP, FX] = F(prob,nOBJ,maxFX);
                    cd('..');
                    T = cputime() - T;

                    IGD = calculaIGD(FX,prob);
                    IGDP = calculaIGDP(FX,prob);
                    HV = calcHV(FX,NADIR);
                    GD = calculaGD(FX,prob);
                    SPREAD = calculaSPREAD(FX,prob);
                    EPS = calculaEPS(FX,prob);
                    
                    arquivo = ['results/' metodo{i} '/' metodo{i} '_' prob '_' num2str(nOBJ) 'D_' num2str(t) '.mat'];
                    if ( ~isfolder(['results/' metodo{i}]))
                        mkdir(['results/' metodo{i}]);
                    end
                  
                    parsave(arquivo,POP,FX,T,IGD,HV,IGDP,GD,SPREAD,EPS);
                    FX = unique(FX,'rows');
                    numPOP = size(FX,1);
                    fprintf('Problema: %6s\tnumOBJ: %2d\tIteração: %2d\tMétodo: %10s\tIGD: %2.6e\t\tHV: %2.6e\t\tTempo: %4.2f\t\t%d\n',prob,nOBJ,t,metodo{i},IGD,HV,T,numPOP);
                end
            end
            fprintf('\n');
        end
    end
end