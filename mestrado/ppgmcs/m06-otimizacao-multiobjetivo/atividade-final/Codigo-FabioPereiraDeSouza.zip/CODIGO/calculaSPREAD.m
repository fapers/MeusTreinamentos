function S = calculaSPREAD(FX,problema)
    
%     addpath('./data');

    numOBJ = size(FX,2);
    
    prob = [problema '_' num2str(numOBJ) '.mat'];
    load(lower(prob));

    I = [min(PF); min(FX)];
    Z = [max(PF); max(FX)];
    
    S = 0;    
    for d = 1:numOBJ
        S = S + ((min(Z(:,d)) - max(I(:,d))) / (Z(1,d) - I(1,d))) ^ 2;
    end
    
    S = sqrt(S/numOBJ);
end