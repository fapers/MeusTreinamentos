function EPS = calculaEPS(FX,problema)
    
    addpath('./data');
    
    [numPOP, numOBJ] = size(FX);

    prob = [problema '_' num2str(numOBJ) '.mat'];
    load(lower(prob));
    
    numPontos = size(PF,1);
        
    D = zeros(numPOP,numPontos);
    
    for i = 1:numPOP
        for j = 1:numPontos
            D(i,j) = max(FX(i,:) - PF(j,:));
        end
    end
    EPS = max(min(D,[],2));
end 