clearvars;
close all;
clc;

cd(fileparts(mfilename('fullpath')));

addpath('data','results');

numEXEC = 1;

metodo = {};
metodo = {metodo{:},'NSGAII'};
metodo = {metodo{:},'MOEA_D'};
metodo = {metodo{:},'MOEA_DDE'};

fprintf('Iniciando testes DTLZ\n');
problema = {'dtlz1','dtlz2','dtlz3','dtlz4'};
numOBJ = [2 3];
batch(problema,numOBJ,metodo,numEXEC);