function parsave(arquivo,POP,FX,T,IGD,HV,IGDP,GD,SPREAD,EPS)
    save(arquivo,'POP','FX','T','IGD','HV','IGDP','GD','SPREAD','EPS');
end