function GD = calculaGD(FX,problema)
    
%     addpath('./data');

    numOBJ = size(FX,2);
    
    prob = [problema '_' num2str(numOBJ) '.mat'];
    load(lower(prob));
    
    numPontos = size(PF,1);
    numPOP = size(FX,1);
    distancia = inf(numPOP,1);
    for i = 1:numPOP
        for j = 1:numPontos
            d = norm(FX(i,:) - PF(j,:));
            if (d < distancia(i))
                distancia(i) = d;
            end
        end
    end
    GD = mean(distancia);    
end