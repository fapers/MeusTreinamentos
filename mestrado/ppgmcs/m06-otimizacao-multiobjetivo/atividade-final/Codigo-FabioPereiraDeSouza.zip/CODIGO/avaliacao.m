 function [HHVmean, HIGDmean, HGDmean, HEPSmean, HSPREADmean, HTmean] = avaliacao(problema,numOBJ,metodo,numEXEC,metNAMES)
    cd(fileparts(mfilename('fullpath')));
    addpath('./data','./results');
    
    global RANK cont00;
    
    LATEX = 0;
    RANKSUM = 1;
    TEMPO = 0;

    cont = 0;

    HHVmean = [];
    HIGDmean = [];
    HGDmean = [];
    HEPSmean = [];
    HSPREADmean = [];
    HTmean = [];
    for n = 1:length(numOBJ)
        for p = 1:length(problema)
            [~, ~, ~, ~, ~, nOBJ] = limites(problema{p},numOBJ(n),0);
            cont = cont + 1;
            IGDhist = [];
            FXhist = [];
            POPhist = [];
            HVhist = [];
            Thist = [];
            FXmin = [];
            HVhist = [];
            HVmax = [];
            maxFX = -inf * ones(1,nOBJ);
                        
            for i = 1:length(metodo)
                for t = 1:numEXEC
                    arquivo = ['results/' metodo{i} '/' metodo{i} '_' problema{p} '_' num2str(nOBJ) 'D_' num2str(t) '.mat'];
                    load(arquivo);
                    maxFX = max(maxFX,max(FX));
                end
            end
            
            for i = 1:length(metodo)
                for t = 1:numEXEC
                    arquivo = ['results/' metodo{i} '/' metodo{i} '_' problema{p} '_' num2str(nOBJ) 'D_' num2str(t) '.mat'];
                    load(arquivo);
                    HVhist(i,t) = HV;
                    IGDhist(i,t) = IGD;
                    GDhist(i,t) = GD;
                    EPShist(i,t) = EPS;
                    SPREADhist(i,t) = SPREAD;
                    Thist(i,t) = T;
                end
                HVmean(i) = median(HVhist(i,:));
                IGDmean(i) = median(IGDhist(i,:));
                GDmean(i) = median(GDhist(i,:));
                EPSmean(i) = median(EPShist(i,:));
                SPREADmean(i) = median(SPREADhist(i,:));
                Tmean(i) = median(Thist(i,:));
                
            end
            
            if (TEMPO == 1)
                cont00 = cont00 + 1;
                subplot(2,2,cont00);
                boxplot(Thist');
                set(gca, 'ActivePositionProperty', 'position', 'FontSize', 16,'LineWidth', 1);
                xticklabels(metNAMES);
                xlabel([upper(problema{p}) ' (m = ' num2str(nOBJ) ')']);
                ylabel('tempo (em segundos)');
                
                drawnow;
            end
            
            if (LATEX == 1)
                fprintf('%10s (%d)',upper(problema{p}),nOBJ);
                HH = HVhist;
                for i = 1:length(metodo)
                    [~, indB] = max(mean(HH'));
                    if (i == indB)
                        fprintf('       & \\cellcolor{gray!40} %3.3f \\scriptsize{(%1.2e)}',mean(HH(i,:)),std(HH(i,:)));
                    else
                        fprintf('       & %3.3f \\scriptsize{(%1.2e)}                    ',mean(HH(i,:)),std(HH(i,:)));
                    end
                end

                fprintf(' \\\\');
                if ((p == length(problema)) && (n == length(numOBJ)))
                    fprintf(' \\hline\n');
                else
                    fprintf('\n');
                end
            end
            
            if (RANKSUM == 1)
                HH = HVhist;
                for i = 2:length(metodo)
                    [p,H] = ranksum(HH(1,:),HH(i,:));
                    if (H == 1)
                        if (mean(HH(1,:)) > mean(HH(i,:)))
                            RANK(i,1) = RANK(i,1) + 1;
                        else
                            RANK(i,3) = RANK(i,3) + 1;                            
                        end
                    else
                        RANK(i,2) = RANK(i,2) + 1;
                    end
                end
            end
            
            HHVmean = [HHVmean; HVmean];
            HIGDmean = [HIGDmean; IGDmean];
            HGDmean = [HGDmean; GDmean];
            HEPSmean = [HEPSmean; EPSmean];
            HSPREADmean = [HSPREADmean; SPREADmean];
            HTmean = [HTmean; Tmean];
        end
    end
 end