function IGD = calculaIGD(FX,problema)
    
%     addpath('./data');

    numOBJ = size(FX,2);
    
    prob = [problema '_' num2str(numOBJ) '.mat'];
    load(lower(prob));
    
    numPontos = size(PF,1);
    numPOP = size(FX,1);
    distancia = inf(numPontos,1);
    for i = 1:numPontos
        for j = 1:numPOP
            d = norm(PF(i,:) - FX(j,:));
            if (d < distancia(i))
                distancia(i) = d;
            end
        end
    end
    IGD = mean(distancia);    
end