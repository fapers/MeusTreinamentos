clear vars;
close all;
clc;

numEXEC = 1;

global RANK cont00;

cont00 = 0;

metodo = {}; metNAMES = {};
metodo = {metodo{:},'NSGAII'}; metNAMES = {metNAMES{:},'NSGA-II'};
metodo = {metodo{:},'MOEA_D'}; metNAMES = {metNAMES{:},'MOEA/D'};
metodo = {metodo{:},'MOEA_DDE'}; metNAMES = {metNAMES{:},'MOEA/D-DE'};

HHV = [];
HIGD = [];
HIGDP = [];
HGD = [];
HEPS = [];
HSPREAD = [];
HT = [];

RANK = zeros(length(metodo),3);

problema = {'dtlz1','dtlz2','dtlz3','dtlz4'}; numOBJ = [2 3];
[HV, IGD, GD, EPS, SPREAD, T] = avaliacao(problema,numOBJ,metodo,numEXEC,metNAMES);
HHV = [HHV; HV]; HIGD = [HIGD; IGD]; HGD = [HGD; GD]; HEPS = [HEPS; EPS]; HSPREAD = [HSPREAD; SPREAD]; HT = [HT; T];
 
RANK

indicadores = {'HHV','-HIGD','-HGD','-HEPS','HSPREAD'};
indicador = {'HV','IGD','GD','EPS','SPREAD'};

XX = [];
R = [];

for i = 1:length(indicadores)
    HH = eval(indicadores{i});
    [~,~,A] = kruskalwallis(HH);
    nCOL = size(HH,2);
    figure(i);
    set(0, 'DefaultLineLineWidth', 3);
    [c,m] = multcompare(A,'Alpha',0.05,'CType','dunn-sidak','Display','off');
    XX(end+1,:) = c(1:nCOL-1,end)';
    R(end+1,:) = c(1:nCOL-1,4)';
    
    fprintf('%10s',indicador{i});
    
    for j = 1:length(metodo)-1
        if (XX(i,j) <= 0.05)
            cor = '0';
            if (R(i,j) >= 0)
                cor = '40';
            end
        else
            cor = '15';
        end
        fprintf(['       & \\cellcolor{gray!' cor '} %1.4f \\scriptsize{(%1.4e)}'],R(i,j),XX(i,j));
    end
    fprintf('\\\\\n');
end
close all