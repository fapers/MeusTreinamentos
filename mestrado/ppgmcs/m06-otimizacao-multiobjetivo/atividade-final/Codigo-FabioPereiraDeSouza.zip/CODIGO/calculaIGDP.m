function IGDP = calculaIGDP(FX,problema)
    
%     addpath('./data');

    numOBJ = size(FX,2);
    
    prob = [problema '_' num2str(numOBJ) '.mat'];
    load(lower(prob));
    
    numPontos = size(PF,1);
    numPOP = size(FX,1);
    distancia = inf(numPontos,1);
    for i = 1:numPontos
        for j = 1:numPOP
            d = max(PF(i,:) - FX(j,:),0);
            d = norm(d);
            if (d < distancia(i))
                distancia(i) = d;
            end
        end
    end
    IGDP = mean(distancia);    
end