function V = initVET(numOBJ)
    switch (numOBJ)
        case 2
            numPONTOS = 100;
        case 3
            numPONTOS = 12;
        case 5
            numPONTOS = 6;
        case 8
            numPONTOS = [3 2];
        case 10
            numPONTOS = [3 2];
        case 15
            numPONTOS = [2 2 1];
    end
    
    switch length(numPONTOS)
        
        case 1
            teta = 1;
        case 2
            teta = [1 0.5];
        case 3
            teta = [1 0.8 0.5];
    end

    V = [];
    for i = 1:length(numPONTOS)
        
        passo = 1/numPONTOS(i);

        A = linspace(0,1,numPONTOS(i));
        I = A;

        for j = 2:numOBJ
            I = combvec(I,A);
            I = I(:,sum(I) <= 1 + passo/2);
        end
        
        I = I(:,abs(sum(I) - 1) < passo/2)';
        I = ((1 - teta(i)) / numOBJ) + teta(i) .* I;

        V = [V; I];
    end
end