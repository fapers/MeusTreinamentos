function FX = calculaFX(POPb,problema,numOBJ,varargin)
    
    [~, ~, ~, xmin, xmax, numOBJ] = limites(problema,numOBJ,0);
    
    [numPOP, numVAR] = size(POPb);
    
    if (nargin >= 4)
        POP = POPb;
    else
        POP = repmat(xmin,numPOP,1) + repmat(xmax-xmin,numPOP,1) .* POPb;
    end
    
    switch problema
        case 'dtlz1'
            G = 100 * (numVAR - numOBJ + 1 + sum((POP(:,numOBJ:end) - 0.5).^2 - cos(20 * pi * (POP(:,numOBJ:end) - 0.5)),2));
            FX(:,1) = (1 + G) .* 0.5 .* prod(POP(:,1:numOBJ-1),2);
            for i = 2:numOBJ - 1
                FX(:,i) = (1 + G) .* 0.5 .* prod(POP(:,1:numOBJ-i),2) .* (1 - POP(:,numOBJ-i+1));
            end
            FX(:,numOBJ) = (1 + G) .* 0.5 .* (1 - POP(:,1));
        case 'dtlz2'
            G = sum((POP(:,numOBJ:end) - 0.5).^2,2);
            FX(:,1) = (1 + G) .* prod(cos(0.5*pi*POP(:,1:numOBJ-1)),2);
            for i = 2:numOBJ - 1
                FX(:,i) = (1 + G) .* prod(cos(0.5*pi*POP(:,1:numOBJ-i)),2) .* sin(0.5*pi*POP(:,numOBJ-i+1));
            end
            FX(:,numOBJ) = (1 + G) .* sin(0.5*pi*POP(:,1));
        case 'dtlz3'
            G = 100 * (numVAR - numOBJ + 1 + sum((POP(:,numOBJ:end) - 0.5).^2 - cos(20 * pi * (POP(:,numOBJ:end) - 0.5)),2));
            FX(:,1) = (1 + G) .* prod(cos(0.5*pi*POP(:,1:numOBJ-1)),2);
            for i = 2:numOBJ - 1
                FX(:,i) = (1 + G) .* prod(cos(0.5*pi*POP(:,1:numOBJ-i)),2) .* sin(0.5*pi*POP(:,numOBJ-i+1));
            end
            FX(:,numOBJ) = (1 + G) .* sin(0.5*pi*POP(:,1));
        case 'dtlz4'
            a = 100;
            G = sum((POP(:,numOBJ:end) - 0.5).^2,2);
            FX(:,1) = (1 + G) .* prod(cos(0.5*pi*(POP(:,1:numOBJ-1).^a)),2);
            for i = 2:numOBJ - 1
                FX(:,i) = (1 + G) .* prod(cos(0.5*pi*(POP(:,1:numOBJ-i).^a)),2) .* sin(0.5*pi*(POP(:,numOBJ-i+1).^a));
            end
            FX(:,numOBJ) = (1 + G) .* sin(0.5*pi*(POP(:,1).^a));
        case 'dtlz5'
            G = sum((POP(:,numOBJ:end) - 0.5).^2,2);
            theta=zeros(size(POP));
            theta(:,1) = POP(:,1);
            theta(:,2:end) = (pi./(4.*(1+repmat(G, [1 size(POP,2)-1])))).*(1+2.*repmat(G, [1 size(POP,2)-1]).*POP(:,2:end));
            FX(:,1) = (1 + G) .* prod(cos(0.5*pi*theta(:,1:numOBJ-1)),2);
            for i = 2:numOBJ - 1
                FX(:,i) = (1 + G) .* prod(cos(0.5*pi*theta(:,1:numOBJ-i)),2) .* sin(0.5*pi*theta(:,numOBJ-i+1));
            end
            FX(:,numOBJ) = (1 + G) .* sin(0.5*pi*theta(:,1));
        case 'dtlz6'
            G = sum((POP(:,numOBJ:end)).^0.1,2);
            theta=zeros(size(POP));
            theta(:,1) = POP(:,1);
            theta(:,2:end) = (pi./(4.*(1+repmat(G, [1 size(POP,2)-1])))).*(1+2.*repmat(G, [1 size(POP,2)-1]).*POP(:,2:end));
            FX(:,1) = (1 + G) .* prod(cos(0.5*pi*theta(:,1:numOBJ-1)),2);
            for i = 2:numOBJ - 1
                FX(:,i) = (1 + G) .* prod(cos(0.5*pi*theta(:,1:numOBJ-i)),2) .* sin(0.5*pi*theta(:,numOBJ-i+1));
            end
            FX(:,numOBJ) = (1 + G) .* sin(0.5*pi*theta(:,1));
        case 'dtlz7'
            G = 1 + sum((POP(:,numOBJ:end)),2).*(9/(numVAR - numOBJ + 1));
            FX(:,1:numOBJ-1) = POP(:,1:numOBJ-1);
            H = numOBJ - sum( (FX(:,1:numOBJ-1)./(1+repmat(G, [1 size(FX,2)]))).*(1 + sin(3*pi*FX(:,1:numOBJ-1)))  ,2);
            FX(:,numOBJ) = (1+G).*H;
        case 'dtlz8'
            for i = 1:numOBJ
                FX(:,i) = (1/floor(numVAR/numOBJ)) * sum( POP (:, floor((i-1)*numVAR/numOBJ)+1 : floor(i*numVAR/numOBJ)),2);
            end
            G = -(repmat(FX(:,numOBJ), [1 numOBJ-1] ) + 4*FX(:,1:numOBJ-1) - 1);
            SUMF = [];
            for i=1:numOBJ-1
                aux = FX;
                auPOP(:,:,i) = -auPOP(:,:,i);
                aux2 =(repmat(FX(:,i),[1 numOBJ-1])+auPOP(:,:,1:numOBJ-1) );
                aux2(:,i) = [];
                SUMF = [SUMF aux2];
            end
            G(:,numOBJ) = -(2*FX(:,numOBJ) + min(SUMF')' - 1);
            FX = FX + 100*repmat(sum(maPOP(:,0,G')',2), [1 size(FX,2)]);

        case 'dtlz9'
            for i = 1:numOBJ
                FX(:,i) = sum( POP (:, floor((i-1)*numVAR/numOBJ)+1 : floor(i*numVAR/numOBJ)).^0.1,2);
            end
            G = - (repmat(FX(:,numOBJ), [1 numOBJ-1]).^2 + FX(:,1:numOBJ-1).^2 - 1);
            FX = FX + 100*repmat(sum(maPOP(:,0,G')',2), [1 size(FX,2)]);

        case 'lz09_f1'
            numVAR = size(POP,2);
            z = 0;
            for j = 3:2:numVAR
                z = z + (POP(:,j) - POP(:,1) .^ (0.5 * (1 + 3 * (j - 2) / (numVAR - 2)))) .^ 2;
            end
            FX(:,1) = POP(:,1) + (2 / length(3:2:numVAR)) * z;
            z = 0;
            for j = 2:2:numVAR
                z = z + (POP(:,j) - POP(:,1) .^ (0.5 * (1 + 3 * (j-2) / (numVAR - 2)))) .^ 2;
            end
            FX(:,2) = 1 - sqrt(POP(:,1)) + (2 / length(2:2:numVAR)) * z;

        case 'lz09_f2'
            numVAR = size(POP,2);
            z = 0;
            for j = 3:2:numVAR
                z = z + (POP(:,j) - sin(6 * pi * POP(:,1) + j * pi / numVAR)) .^ 2;
            end
            FX(:,1) = POP(:,1) + (2 / length(3:2:numVAR)) * z;
            z = 0;
            for j = 2:2:numVAR
                z = z + (POP(:,j) - sin(6 * pi * POP(:,1) + j * pi / numVAR)) .^ 2;
            end
            FX(:,2) = 1 - sqrt(POP(:,1)) + (2 / length(2:2:numVAR)) * z;

        case 'lz09_f3'
            numVAR = size(POP,2);
            z = 0;
            for j = 3:2:numVAR
                z = z + (POP(:,j) - 0.8 * POP(:,1) .* cos(6 * pi * POP(:,1) + j * pi ./ numVAR)) .^ 2;
            end
            FX(:,1) = POP(:,1) + (2 / length(3:2:numVAR)) * z;
            z = 0;
            for j = 2:2:numVAR
                z = z + (POP(:,j) - 0.8 * POP(:,1) .* sin(6 * pi * POP(:,1) + j * pi / numVAR)) .^ 2;
            end
            FX(:,2) = 1 - sqrt(POP(:,1)) + (2 / length(2:2:numVAR)) * z;

        case 'lz09_f4'
            numVAR = size(POP,2);
            z = 0;
            for j = 3:2:numVAR
                z = z + (POP(:,j) - 0.8 * POP(:,1) .* cos((6 * pi * POP(:,1) + j * pi / numVAR) / 3)) .^ 2;
            end
            FX(:,1) = POP(:,1) + (2 / length(3:2:numVAR)) * z;
            z = 0;
            for j = 2:2:numVAR
                z = z + (POP(:,j) - 0.8 * POP(:,1) .* sin(6 * pi * POP(:,1) + j * pi / numVAR)) .^ 2;
            end
            FX(:,2) = 1 - sqrt(POP(:,1)) + (2 / length(2:2:numVAR)) * z;

        case 'lz09_f5'
            numVAR = size(POP,2);
            z = 0;
            for j = 3:2:numVAR
                z = z + (POP(:,j) - (0.3 * (POP(:,1) .^ 2) .* cos(24 * pi * POP(:,1) + 4 * j * pi / numVAR) + 0.6 * POP(:,1)) .* cos(6 * pi * POP(:,1) + j * pi / numVAR)) .^ 2;
            end
            FX(:,1) = POP(:,1) + (2 / length(3:2:numVAR)) * z;
            z = 0;
            for j = 2:2:numVAR
                z = z + (POP(:,j) - (0.3 * (POP(:,1) .^ 2) .* cos(24 * pi * POP(:,1) + 4 * j * pi / numVAR) + 0.6 * POP(:,1)) .* sin(6 * pi * POP(:,1) + j * pi / numVAR)) .^ 2;
            end
            FX(:,2) = 1 - sqrt(POP(:,1)) + (2 / length(2:2:numVAR)) * z;

        case 'lz09_f6'
            [~,numVAR] = size(POP);

            z = 0;
            for j = 4:3:numVAR    
                z = z + (POP(:,j) - 2 * POP(:,2) .* sin(2 * pi *POP(:,1) + j *pi/numVAR)) .^ 2;
            end
            FX(:,1) = cos(0.5*POP(:,1)*pi) .* cos(0.5*POP(:,2)*pi) + (2/length(4:3:numVAR))*z;

            z = 0;
            for j = 5:3:numVAR
                z = z + (POP(:,j) - 2*POP(:,2) .* sin(2*pi*POP(:,1) + j*pi/numVAR)) .^ 2;
            end
            FX(:,2) = cos(0.5*POP(:,1)*pi) .* sin(0.5*POP(:,2)*pi) + (2/length(5:3:numVAR))*z;

            z = 0;
            for j = 3:3:numVAR
                z = z + (POP(:,j) - 2*POP(:,2) .* sin(2*pi*POP(:,1) + j*pi/numVAR)) .^ 2;
            end
            FX(:,3) = sin(0.5*POP(:,1)*pi) + (2/length(3:3:numVAR))*z;
        case 'lz09_f7'
            [numPOP,numVAR] = size(POP);
            y = zeros(numPOP,numVAR);
            for j = 2:numVAR
                y(:,j) = POP(:,j) - POP(:,1) .^ (0.5 * (1 + 3 * (j-2) / (numVAR-2)));
            end
            z = 0;
            for j = 3:2:numVAR
                z = z + (4 * y(:,j) .^2 - cos(8 * y(:,j) * pi) + 1.0);
            end
            FX(:,1) = POP(:,1) + (2 / length(3:2:numVAR)) * z;
            z = 0;
            for j = 2:2:numVAR
                z = z + (4 * y(:,j) .^ 2 - cos(8 * y(:,j) * pi) + 1.0);
            end
            FX(:,2) = 1 - sqrt(POP(:,1)) + (2/length(2:2:numVAR)) * z;

        case 'lz09_f8'
            [numPOP,numVAR] = size(POP);
            y = zeros(numPOP,numVAR);
            for j = 2:numVAR
                y(:,j) = POP(:,j) - POP(:,1) .^ (0.5 * (1 + 3 * (j-2) / (numVAR - 2)));
            end
            z = 4 * sum(y(:,3:2:numVAR) .^ 2,2) - 2 .* prod(cos(20 * y(:,3:2:numVAR) .* pi ./ repmat(sqrt(3:2:numVAR),numPOP,1)),2) + 2;

            FX(:,1) = POP(:,1) + (2 / length(3:2:numVAR)) * z;

            z = 4 * sum(y(:,2:2:numVAR) .^ 2,2) - 2 .* prod(cos(20 * y(:,2:2:numVAR) .* pi ./ repmat(sqrt(2:2:numVAR),numPOP,1)),2) + 2;
            FX(:,2) = 1 - sqrt(POP(:,1)) + (2/length(2:2:numVAR))*z;

        case 'lz09_f9'
            numVAR = size(POP,2);
            z = 0;
            for j = 3:2:numVAR
                z = z + (POP(:,j) - sin(6 * pi * POP(:,1) + j * pi / numVAR)) .^ 2;
            end
            FX(:,1) = POP(:,1) + (2 / length(3:2:numVAR)) * z;
            z = 0;
            for j = 2:2:numVAR
                z = z + (POP(:,j) - sin(6 * pi * POP(:,1) + j * pi / numVAR)) .^ 2;
            end
            FX(:,2) = 1 - POP(:,1) .^ 2 + (2 / length(2:2:numVAR)) * z;

        case 'wfg1'
            FX = WFG(POP,numOBJ,1);
        case 'wfg2'
            FX = WFG(POP,numOBJ,2);
        case 'wfg3'
            FX = WFG(POP,numOBJ,3);
        case 'wfg4'
            FX = WFG(POP,numOBJ,4);
        case 'wfg5'
            FX = WFG(POP,numOBJ,5);
        case 'wfg6'
            FX = WFG(POP,numOBJ,6);
        case 'wfg7'
            FX = WFG(POP,numOBJ,7);
        case 'wfg8'
            FX = WFG(POP,numOBJ,8);
        case 'wfg9'
            FX = WFG(POP,numOBJ,9);        
        otherwise
            fprintf('PROBLEMA NÃO ENCONTRADO');
    end
end