function [numVAR, nomePROB, maxFX, xmin, xmax, numOBJ, PF, tamPOP] = limites(problema,numOBJ,flag)

    numGER = 1000;
    i = 1;
    
    maxFX = [];

    switch numOBJ
        case 2
            tamPOP = 100;
            i = 1;
        case 3
            tamPOP = 91;
            i = 1;
        case 5
            tamPOP = 210;
            i = 2;
        case 8
            tamPOP = 156;
            i = 3;
        case 10
            tamPOP = 275;
            i = 4;
        case 15
            tamPOP = 135;
            i = 5;
        case 20
            tamPOP = 230;
            i = 5;
    end
    
    switch lower(problema)
        case 'dtlz1'
            numVAR = numOBJ + 4;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
            numGER = [400 600 750 1000 1500];
        case 'dtlz2'
            numVAR = numOBJ + 9;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
            numGER = [250 350 500 750 1000];
        case 'dtlz3'
            numVAR = numOBJ + 9;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
            numGER = [1000 1000 1000 1500 2000];
        case 'dtlz4'
            numVAR = numOBJ + 9;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
            numGER = [600 1000 1250 2000 3000];
        case 'dtlz5'
            numVAR = numOBJ + 9;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
            numGER = [200 300 500 750 1000];
        case 'dtlz6'
            numVAR = numOBJ + 9;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
            numGER = [500 1000 1250 2000 3000];
        case 'dtlz7'
            numVAR = numOBJ + 19;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
            numGER = [200 300 500 750 1000];
        case 'dtlz8'
            numVAR = numOBJ * 10;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
            numGER = [500 1000 1250 2000 3000];
        case 'dtlz9'
            numVAR = numOBJ * 10;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
            numGER = [500 1000 1250 2000 3000];
        case 'lz09_f1'
            numVAR = 30;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
            numOBJ = 2;
        case 'lz09_f2'
            numVAR = 30;
            xmin = [0 -ones(1,numVAR-1)];
            xmax = ones(1,numVAR);
            numOBJ = 2;
        case 'lz09_f3'
            numVAR = 30;
            xmin = [0 -ones(1,numVAR-1)];
            xmax = ones(1,numVAR);
            numOBJ = 2;
        case 'lz09_f4'
            numVAR = 30;
            xmin = [0 -ones(1,numVAR-1)];
            xmax = ones(1,numVAR);
            numOBJ = 2;
        case 'lz09_f5'
            numVAR = 30;
            xmin = [0 -ones(1,numVAR-1)];
            xmax = ones(1,numVAR);
            numOBJ = 2;
        case 'lz09_f6'
            numVAR = 10;
            xmin = [0 0 -2 * ones(1,numVAR-2)];
            xmax = [1 1  2 * ones(1,numVAR-2)];
            numOBJ = 3;
        case 'lz09_f7'
            numVAR = 10;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
            numOBJ = 2;
        case 'lz09_f8'
            numVAR = 10;
            xmin = zeros(1,numVAR);
            xmax = ones(1,numVAR);
        case 'lz09_f9'
            numVAR = 30;
            xmin = [0 -ones(1,numVAR-1)];
            xmax = ones(1,numVAR);
            numOBJ = 2;
        case {'wfg1','wfg2','wfg3','wfg4','wfg5','wfg6','wfg7','wfg8','wfg9'}
            numVAR = 30;
            xmin = zeros(1,numVAR);
            xmax = 2*(1:numVAR);
            tamPOP = 100;
            numGER = 1000;
            i = 1;
        case {'maf1'}
            numVAR = numOBJ + 9;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf2'}
            numVAR = numOBJ + 9;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf3'}
            numVAR = numOBJ + 9;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf4'}
            numVAR = numOBJ + 9;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf5'}
            numVAR = numOBJ + 9;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf6'}
            numVAR = numOBJ + 9;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf7'}
            numVAR = numOBJ + 19;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf8'}
            numVAR = 2;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf9'}
            numVAR = 2;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf10'}
            numVAR = numOBJ + 9;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf11'}
            numVAR = numOBJ + 9;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf12'}
            numVAR = numOBJ + 9;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf13'}
            numVAR = 5;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf14'}
            numVAR = numOBJ*20;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
        case {'maf15'}
            numVAR = numOBJ*20;
            xmin = [];
            xmax = [];
            tamPOP = 210;
            maxFX = max(1e5,10000*numVAR);
            i = 1;
    end
    if (isempty(maxFX))
        maxFX = tamPOP * numGER(i);
    end
    if (flag == 1)
        nomePROB = strcat(problema,'_',num2str(numOBJ),'.mat');        
        load(lower(nomePROB));
    else
        nomePROB = [];
        PF = [];
    end
end