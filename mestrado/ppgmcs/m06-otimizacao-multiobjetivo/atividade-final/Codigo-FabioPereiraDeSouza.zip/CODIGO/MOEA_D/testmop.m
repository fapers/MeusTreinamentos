function mop = testmop(problema, numVAR, numOBJ)
%Get test multi-objective problems from a given name.
%   The method get testing or benchmark problems for Multi-Objective
%   Optimization. The implemented problems included ZDT, OKA, KNO.
%   User get the corresponding test problem, which is an instance of class
%   mop, by passing the problem name and optional numVAR parameters.


mop=struct('name',[],'od',[],'pd',[],'domain',[],'func',[]);
    switch lower(problema)
        case 'kno1'
            mop=kno1(mop);
        case 'zdt1'
            mop=zdt1(mop, numVAR);
        case 'zdt3'
            mop=zdt3(mop, numVAR);
        case 'dtlz1'
            mop=dtlz1(mop, numVAR, numOBJ);
        case 'dtlz2'
            mop=dtlz2(mop, numVAR, numOBJ);
        case 'dtlz3'
            mop=dtlz3(mop, numVAR, numOBJ);
        case 'dtlz4'
            mop=dtlz4(mop, numVAR, numOBJ);
        case 'dtlz5'
            mop=dtlz5(mop, numVAR, numOBJ);
        case 'dtlz6'
            mop=dtlz6(mop, numVAR, numOBJ);
        case 'dtlz7'
            mop=dtlz7(mop, numVAR, numOBJ);
        case 'dtlz8'
            mop=dtlz8(mop, numVAR, numOBJ);
        case 'dtlz9'
            mop=dtlz9(mop, numVAR, numOBJ);
        case 'lz09_f1'
            mop=lz09_f1(mop, numVAR);
        case 'lz09_f2'
            mop=lz09_f2(mop, numVAR);
        case 'lz09_f3'
            mop=lz09_f3(mop, numVAR);
        case 'lz09_f4'
            mop=lz09_f4(mop, numVAR);
        case 'lz09_f5'
            mop=lz09_f5(mop, numVAR);
        case 'lz09_f6'
            mop=lz09_f6(mop, numVAR);
        case 'lz09_f7'
            mop=lz09_f7(mop, numVAR);
        case 'lz09_f8'
            mop=lz09_f8(mop, numVAR);
        case 'lz09_f9'
            mop=lz09_f9(mop, numVAR);
        case 'wfg1'
            mop=wfg1(mop, numVAR, numOBJ);
        case 'wfg2'
            mop=wfg2(mop, numVAR, numOBJ);
        case 'wfg3'
            mop=wfg3(mop, numVAR, numOBJ);
        case 'wfg4'
            mop=wfg4(mop, numVAR, numOBJ);
        case 'wfg5'
            mop=wfg5(mop, numVAR, numOBJ);
        case 'wfg6'
            mop=wfg6(mop, numVAR, numOBJ);
        case 'wfg7'
            mop=wfg7(mop, numVAR, numOBJ);
        case 'wfg8'
            mop=wfg8(mop, numVAR, numOBJ);
        case 'wfg9'
            mop=wfg9(mop, numVAR, numOBJ);
        otherwise
            error('Undefined test problem name');
    end
end

%KNO1 function generator
function p=kno1(p)
 p.name='KNO1';
 p.od = numOBJ;
 p.pd = 2;
 p.domain= [0 3;0 3];
 p.func = @evaluate;
 
    %KNO1 evaluation function.
    function y = evaluate(x)
      y=zeros(2,1);
	  c = x(1)+x(2);
	  f = 9-(3*sin(2.5*c^0.5) + 3*sin(4*c) + 5 *sin(2*c+2));
	  g = (pi/2.0)*(x(1)-x(2)+3.0)/6.0;
	  y(1)= 20-(f*cos(g));
	  y(2)= 20-(f*sin(g)); 
    end
end


%ZDT1 function generator (solve also with f2 = 10*f2)
function p=zdt1(p,numVAR)
 p.name='ZDT1';
 p.pd=numVAR;
 p.od=2;
 p.domain=[zeros(numVAR,1) ones(numVAR,1)];
 p.func=@evaluate;
 
    %ZDT1 evaluation function.
    function y=evaluate(x)
        y=zeros(2,1);
        y(1) = x(1);
    	su = sum(x)-x(1);    
		g = 1 + 9 * su / (numVAR - 1);
		y(2) = g*(1 - sqrt(x(1) / g));
        %y(2) = 5*y(2);
    end
end

%ZDT3 function generator
function p=zdt3(p,numVAR)
 p.name='ZDT3';
 p.pd=numVAR;
 p.od=2;
 p.domain=[zeros(numVAR,1) ones(numVAR,1)];
 p.func=@evaluate;
 
    %ZDT3 evaluation function.
    function y=evaluate(x)
        y=zeros(2,1);
        y(1) = x(1);
    	su = sum(x)-x(1);    
		g = 1 + 9 * su / (numVAR - 1);
		y(2) = g*(1 - sqrt(x(1) / g) - (x(1)/g)*sin(10*pi*x(1)));
    end
end

function p=dtlz1(p,numVAR,numOBJ)
 p.name='DTLZ1';
 k = 5;
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) ones(numVAR,1)];
 p.func=@evaluate;
 
    %DTLZ1 evaluation function.
    function y=evaluate(x)
        y=zeros(p.od,1);        
        s = 0;
        for i = p.od:numVAR, s = s + (x(i)-0.5)^2 - cos(20*pi*(x(i)-0.5)); end
        g = 100*(k+s);

        y(1) = 0.5 * prod(x(1:p.od-1)) * (1+g);
        for i = 2:p.od-1
            y(i) = 0.5 * prod(x(1:p.od-i)) * (1-x(p.od-i+1)) * (1+g);
            %y(i) = 2*y(i); %10^(i-1)*y(i);
        end
        y(p.od) = 0.5 * (1-x(1)) * (1+g);
        %y(p.od) = 5*y(p.od); %10^(p.od-1)*y(p.od);
    end
end

function p=dtlz2(p,numVAR,numOBJ)
 p.name='DTLZ2';
 k = 10;
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) ones(numVAR,1)];
 p.func=@evaluate;
 
    %DTLZ2 evaluation function.
    function y=evaluate(x)
        y=zeros(p.od,1);        
        s = 0;
        for i = p.od:numVAR, s = s + (x(i)-0.5)^2; end
        g = s;

        cosx = cos(x*pi/2);
        sinx = sin(x*pi/2);

        y(1) = (1+g) * prod(cosx(1:p.od-1));
        for i = 2:p.od-1
            y(i) = (1+g) * prod(cosx(1:p.od-i)) * sinx(p.od-i+1);
            %y(i) = 10^(i-1)*y(i);
        end
        y(p.od) = (1+g) * sinx(1);
        %y(p.od) = 10^(p.od-1)*y(p.od);
    end
end

function p=dtlz3(p,numVAR,numOBJ)
 p.name='DTLZ3';
 k = 10;
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) ones(numVAR,1)];
 p.func=@evaluate;
 
    function y=evaluate(x)
        
        s = 0;
        for i = p.od:numVAR
            s = s + (x(i)-0.5)^2 - cos(20*pi*(x(i)-0.5));
        end
        g = 100*(k+s);

        cosx = cos(x*pi/2);
        sinx = sin(x*pi/2);

        f(1) = (1+g) * prod(cosx(1:p.od-1));
        for i = 2:p.od-1
            f(i) = (1+g) * prod(cosx(1:p.od-i)) * sinx(p.od-i+1);
        end
        f(p.od) = (1+g) * sinx(1);

        y = f(:);
    end
end

function p=dtlz4(p,numVAR,numOBJ)
p.name='DTLZ4';
k = 10;
p.pd = numVAR;
p.od = numOBJ;
p.domain=[zeros(numVAR,1) ones(numVAR,1)];
p.func=@evaluate;

    function y=evaluate(x)
        
        a = 100;
        G = sum((x(p.od:end) - 0.5).^2);
        f(1) = (1 + G) .* prod(cos(0.5*pi*(x(1:p.od-1).^a)));
        for i = 2:p.od - 1
            f(i) = (1 + G) .* prod(cos(0.5*pi*(x(1:p.od-i).^a))) .* sin(0.5*pi*(x(p.od-i+1).^a));
        end
        f(p.od) = (1 + G) .* sin(0.5*pi*(x(1).^a));
        
        y = f(:);
    end
end

function p=dtlz5(p,numVAR,numOBJ)
p.name='DTLZ5';
k = 10;
p.pd = numVAR;
p.od = numOBJ;
p.domain=[zeros(numVAR,1) ones(numVAR,1)];
p.func=@evaluate;

    function y=evaluate(x)
        G = sum((x(p.od:end) - 0.5).^2);
        theta=zeros(size(x));
        theta(1) = x(1);
        theta(2:end) = (pi ./ (4.*(1+G))).*(1+2.*G .* x(2:end));
        f(1) = (1 + G) .* prod(cos(0.5 * pi * theta(1:p.od-1)));
        for i = 2:p.od - 1
            f(i) = (1 + G) .* prod(cos(0.5*pi*theta(1:p.od-i))) .* sin(0.5*pi*theta(p.od-i+1));
        end
        f(p.od) = (1 + G) .* sin(0.5*pi*theta(1));
        
        y = f(:);
    end
end


function p=dtlz6(p,numVAR,numOBJ)
p.name='DTLZ6';
k = 10;
p.pd = numVAR;
p.od = numOBJ;
p.domain=[zeros(numVAR,1) ones(numVAR,1)];
p.func=@evaluate;

    function y=evaluate(x)
        G = sum((x(p.od:end)).^0.1);
        theta=zeros(size(x));
        theta(1) = x(1);
        theta(2:end) = (pi./(4 .* (1+G))) .* (1 + 2 .* G .* x(2:end));
        f(1) = (1 + G) .* prod(cos(0.5 * pi * theta(1:p.od-1)));
        for i = 2:p.od - 1
            f(i) = (1 + G) .* prod(cos(0.5 * pi * theta(1:p.od-i))) .* sin(0.5 * pi * theta(p.od-i+1));
        end
        f(p.od) = (1 + G) .* sin(0.5 * pi * theta(1));
        
        y = f(:);
    end
end

function p=dtlz7(p,numVAR,numOBJ)
p.name='DTLZ7';
k = 20;
p.pd = numVAR;
p.od = numOBJ;
p.domain=[zeros(numVAR,1) ones(numVAR,1)];
p.func=@evaluate;

    function y=evaluate(x)
        G = 1 + sum((x(p.od:end))) .* (9/(numVAR - p.od + 1));
        f(1:p.od-1) = x(1:p.od-1);
        H = p.od - sum((f(1:p.od-1) ./ (1 + G)) .* (1 + sin(3 * pi * f(1:p.od-1))));
        f(p.od) = (1 + G) .* H;
        
        y = f(:);
    end
end



function p=lz09_f1(p,numVAR)
 p.name='LZ09 F1';
 p.pd = numVAR;
 p.od = 2;
 p.domain=[zeros(numVAR,1) ones(numVAR,1)];
 p.func=@evaluate;
 
    function y=evaluate(x)        
        y = lz09_f1_eval(x);
    end
end

function p=lz09_f2(p,numVAR)
 p.name='LZ09 F2';
 p.pd = numVAR;
 p.od = 2;
 p.domain=[zeros(numVAR,1) ones(numVAR,1)];
 p.func=@evaluate;
 
    function y=evaluate(x)        
        y = lz09_f2_eval(x);
    end
end

function p=lz09_f3(p,numVAR)
 p.name='LZ09 F3';
 p.pd = numVAR;
 p.od = 2;
 p.domain=[0 1; -ones(numVAR-1,1) ones(numVAR-1,1)];
 p.func=@evaluate;
 
    function y=evaluate(x)        
        y = lz09_f3_eval(x);
    end
end

function p=lz09_f4(p,numVAR)
 p.name='LZ09 F4';
 p.pd = numVAR;
 p.od = 2;
 p.domain=[0 1; -ones(numVAR-1,1) ones(numVAR-1,1)];
 p.func=@evaluate;
 
    function y=evaluate(x)        
        y = lz09_f4_eval(x);
    end
end

function p=lz09_f5(p,numVAR)
 p.name='LZ09 F5';
 p.pd = numVAR;
 p.od = 2;
 p.domain=[0 1; -ones(numVAR-1,1) ones(numVAR-1,1)];
 p.func=@evaluate;
 
    function y=evaluate(x)        
        y = lz09_f5_eval(x);
    end
end

function p=lz09_f6(p,numVAR)
 p.name='LZ09 F6';
 p.pd = numVAR;
 p.od = 3;
 p.domain=[0 1; 0 1; -2*ones(numVAR-2,1) 2*ones(numVAR-2,1)];
 p.func=@evaluate;
 
    function y=evaluate(x)
        y = lz09_f6_eval(x);
    end
end

function p=lz09_f7(p,numVAR)
 p.name='LZ09 F7';
 p.pd = numVAR;
 p.od = 2;
 p.domain=[zeros(numVAR,1) ones(numVAR,1)];
 p.func=@evaluate;
 
    function y=evaluate(x)        
        y = lz09_f7_eval(x);
    end
end

function p=lz09_f8(p,numVAR)
 p.name='LZ09 F8';
 p.pd = numVAR;
 p.od = 2;
 p.domain=[zeros(numVAR,1) ones(numVAR,1)];
 p.func=@evaluate;
 
    function y=evaluate(x)
        y = lz09_f8_eval(x);
    end
end

function p=lz09_f9(p,numVAR)
 p.name='LZ09 F9';
 p.pd = numVAR;
 p.od = 2;
 p.domain=[0 1; -ones(numVAR-1,1) ones(numVAR-1,1)];
 p.func=@evaluate;
 
    function y=evaluate(x)        
        y = lz09_f9_eval(x);
    end
end

function p=wfg1(p,numVAR,numOBJ)
 p.name='WFG 1';
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) 2*transpose((1:numVAR))];
 p.func=@evaluate;
 
    function y=evaluate(x)
        y = WFG(x',p.od,1);
        y = y';
    end
end

function p=wfg2(p,numVAR,numOBJ)
 p.name='WFG 2';
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) 2*transpose((1:numVAR))];
 p.func=@evaluate;
 
    function y=evaluate(x)
        y = WFG(x',p.od,2);
        y = y';
    end
end

function p=wfg3(p,numVAR,numOBJ)
 p.name='WFG 3';
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) 2*transpose((1:numVAR))];
 p.func=@evaluate;
 
    function y=evaluate(x)
        y = WFG(x',p.od,3);
        y = y';
    end
end

function p=wfg4(p,numVAR,numOBJ)
 p.name='WFG 4';
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) 2*transpose((1:numVAR))];
 p.func=@evaluate;
 
    function y=evaluate(x)
        y = WFG(x',p.od,4);
        y = y';
    end
end

function p=wfg5(p,numVAR,numOBJ)
 p.name='WFG 5';
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) 2*transpose((1:numVAR))];
 p.func=@evaluate;
 
    function y=evaluate(x)
        y = WFG(x',p.od,5);
        y = y';
    end
end

function p=wfg6(p,numVAR,numOBJ)
 p.name='WFG 6';
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) 2*transpose((1:numVAR))];
 p.func=@evaluate;
 
    function y=evaluate(x)
        y = WFG(x',p.od,6);
        y = y';
    end
end

function p=wfg7(p,numVAR,numOBJ)
 p.name='WFG 7';
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) 2*transpose((1:numVAR))];
 p.func=@evaluate;
 
    function y=evaluate(x)
        y = WFG(x',p.od,7);
        y = y';
    end
end

function p=wfg8(p,numVAR,numOBJ)
 p.name='WFG 8';
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) 2*transpose((1:numVAR))];
 p.func=@evaluate;
 
    function y=evaluate(x)
        y = WFG(x',p.od,8);
        y = y';
    end
end

function p=wfg9(p,numVAR,numOBJ)
 p.name='WFG 9';
 p.pd = numVAR;
 p.od = numOBJ;
 p.domain=[zeros(numVAR,1) 2*transpose((1:numVAR))];
 p.func=@evaluate;
 
    function y=evaluate(x)
        y = WFG(x',p.od,9);
        y = y';
    end
end