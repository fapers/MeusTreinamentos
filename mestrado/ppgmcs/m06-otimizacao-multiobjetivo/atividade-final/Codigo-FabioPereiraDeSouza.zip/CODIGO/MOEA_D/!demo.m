function pareto=demo()

%mop = testmop('kno1',30);
%mop = testmop('zdt1',30);
%mop = testmop('zdt3',30);
nobj = 3; nvar = nobj+5-1; mop = testmop('dtlz1',nvar);  
%nobj = 3; nvar = nobj+10-1; mop = testmop('dtlz2',nvar);
%nobj = 3; nvar = nobj+10-1; mop = testmop('dtlz3',nvar);
%nobj = 3; nvar = nobj+10-1; mop = testmop('dtlz4',nvar);


%pareto = moead( mop);
pareto = moead( mop, 'popsize', 0, 'niche', 20, 'iteration', 200, 'method', 'te'); % Weighted Tchebycheff
%pareto = moead( mop, 'popsize', 0, 'niche', 20, 'iteration', 200, 'method', 'ws'); % Weighted Sum
%pareto = moead( mop, 'popsize', 0, 'niche', 20, 'iteration', 200, 'method', 'pbi'); % Penalt-based Boundary Intersection
%pareto = moead( mop, 'popsize', 0, 'niche', 20, 'iteration', 200, 'method', 'tem'); % Modified Weighted Tchebycheff (Lianny CBIC 2015)
end
