function subp=init_weights(popsize, niche, objDim)
% init_weights function initialize a population of subproblems structure
% with the generated decomposition weight and the neighbourhood
% relationship.
    subp = [];    
    
    switch objDim
        case 2
            samplingsize = 99;      % N = 100
        case 3
            samplingsize = 12;      % N = 91
        case 5
            samplingsize = 6;       % N = 210
        case 8
            samplingsize = [3 2];   % N = 156
        case 10
            samplingsize = [3 2];   % N = 275
        case 15
            samplingsize = [2 2 1]; % N = 255
        otherwise
            warning('samplingsize doesnot specified for the objDim given.');
    end
    
    w = reference_vectors(objDim,samplingsize);
    
    popsize = size(w,2);
    for i=1:popsize
        p = struct('weight',[],'neighbour',[],'optimal',Inf,'optpoint',[],'curpoint',[]);
        p.weight = w(:,i);
        subp = [subp p];
    end
    
    %Set up the neighbourhood.
    leng=length(subp);
    distanceMatrix=zeros(leng, leng);
    for i=1:leng
        for j=i+1:leng
            A=subp(i).weight;
            B=subp(j).weight;
            distanceMatrix(i,j)=(A-B)'*(A-B);
            distanceMatrix(j,i)=distanceMatrix(i,j);
        end
        [s,sindex]=sort(distanceMatrix(i,:));
        subp(i).neighbour=sindex(1:niche)';
    end   
end





function w = reference_vectors(M,p)

n = length(p);
if (n == 1)
    % one-layer weight vector generation method
    w = DASandDENNIS(M,p); 
else
    % multi-layer weight vector generation method
    % the biggest sample size is used for the boundary layer
    % the smallest sample size is used for the inside layer
    p = sort(p,'descend');
    
    w = [];
    if (n==2), tal = [1 0.5]; 
    elseif (n==3), tal = [1 0.8 0.5]; end
    
    for i = 1:n
        z = DASandDENNIS(M,p(i)); % Das and Dennis approach 
        z = coordinate_tranformation(z,tal(i),M);
        w = [w z]; % reference vectors
    end
end

    function z = coordinate_tranformation(z,tal,M)
        % the coordinates of weight vectors in the inside layer are shrunk 
        % by a coordinate transformation
        z = tal*z + (1-tal)/M;
    end
end





function w = DASandDENNIS(M,p)

% set equally spacing for other objectives
for i = 1:M-1
    NumPoints(i) = p;
end

% partitioned into the first objective
Beta1 = (0:(NumPoints(1)))'/NumPoints(1);

% save the previous values
Beta = Beta1;
for i = 2:M-1
    % compute the combination i.e. p*(p-1)*(p-2)*,...,*0
    ki = round((1-sum(Beta1,2))*NumPoints(i));
    Beta = [];
    for j = 1:size(Beta1,1)
        % compute each subvector of (0,1,...p)/p,(0,1,...p-1)/p,...
        BetaVec = (0:ki(j))'/NumPoints(i);
        numOfreplications = length(BetaVec); % identify the length
        % replicate each of the previous values in the equal size to all the subvectors
        Beta = [Beta; [repmat(Beta1(j,:), numOfreplications,1) BetaVec] ];
    end
    Beta1 = Beta;
end
% compute the last objective values
BetaVec = 1 - sum(Beta1,2);
w = [Beta BetaVec]'; %include the last objective values
end


