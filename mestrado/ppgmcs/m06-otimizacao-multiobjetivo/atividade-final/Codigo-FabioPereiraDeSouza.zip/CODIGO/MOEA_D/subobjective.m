function obj = subobjective(weight, ind, idealpoint, method, nadirpoint)
%SUBOBJECTIVE function evaluate a point's objective with a given method of
%decomposition. 

%   Two methods are implemented by far is Weighted-Sum and Tchebesheff.
%   weight: is the decomposition weight.(column wise vector).
%   ind: is the individual point(column wise vector).
%   idealpoint: the idealpoint for Tchebesheff decomposition.
%   method: is the decomposition method, the default is 'te' when is
%   omitted.
%   
%   weight and ind can also be matrix. in which have two scenairos:
%   When weight is a matrix, then it's treated as a column wise set of
%   weights. in that case, if ind is a size 1 column vector, then the
%   subobjective is computed with every weight and the ind; if ind is also
%   a matrix of the same size as weight, then the subobjective is computed
%   in a column-to-column, with each column of weight computed against the
%   corresponding column of ind. 
%   A row vector of subobjective is return in both case.

    if (nargin==2)
        obj = ws(weight, ind);    
    else
        if strcmp(method, 'ws')
            obj = ws(weight, ind);
        elseif strcmp(method, 'te')
            obj = te(weight, ind, idealpoint, nadirpoint);
        elseif strcmp(method, 'tem')
            obj = tem(weight, ind, idealpoint, nadirpoint);
        elseif strcmp(method, 'pbi')
            obj = pbi(weight, ind, idealpoint);
        else
            obj = pbi(weight, ind, idealpoint);
        end
    end
end



% % WS approach
function obj = ws(weight, ind)
    if size(ind, 2) == 1 
       obj = (weight'*ind)';
    else
       obj = sum(weight.*ind);
    end
end



% % TE approach
function obj = te(weight, ind, idealpoint, ~)
    s = size(weight,2);
    indsize = size(ind,2);
    
    weight((weight == 0))=0.00001;
    
    if indsize==s         
        part2 = abs(ind-idealpoint(:,ones(1,indsize)));    
        obj = max(weight.*part2);
    elseif indsize == 1        
        part2 = abs(ind-idealpoint);
        obj = max(weight.*part2(:,ones(1,s)));
    else
        error('individual size must be same as weight size, or equals 1');
    end
end



% % Proposed TE (Lianny CBIC 2015)
function obj = tem(weight, ind, idealpoint, ~)
    [n,s] = size(weight);
    indsize = size(ind,2);
    
    weight((weight == 0))=0.00001;
    
    wght = 1./weight;
    sumw = sum(wght);
    wght = vec2mat(wght(:)' ./ reshape(sumw(ones(1,n),:),1,n*s), n)';
    
    if indsize==s 
        part2 = abs(ind-idealpoint(:,ones(1,indsize)));        
        obj = max(wght.*part2);
    elseif indsize == 1
        part2 = abs(ind-idealpoint);
        obj = max(wght.*part2(:,ones(1,s)));
    else
        error('individual size must be same as weight size, or equals 1');
    end
end



% % PBI approach
function obj = pbi(weight, ind, idealpoint)
    
    theta = 5;
    [n,s] = size(weight);
    indsize = size(ind,2);
    
    weight((weight == 0))=0.00001;
    
    if indsize==s 
        
        normweight = (sum(weight.^2,1)).^(1/2);
        d1 = abs(sum((ind-idealpoint(:,ones(1,s))).*weight, 1)) ./ normweight;
        w = normweight(ones(1,n),:);
        u = vec2mat(weight(:) ./ w(:), n)';        
        y  = ind - (idealpoint(:,ones(1,s)) + d1(ones(1,n),:) .* u);
        d2 = (sum(y.^2,1)).^(1/2);
        obj = d1 + theta * d2;
        
    elseif indsize == 1
        
        normweight = (sum(weight.^2,1)).^(1/2);
        d1 = abs((ind-idealpoint)'*weight) ./ normweight;
        w = normweight(ones(1,n),:);
        u = vec2mat(weight(:) ./ w(:), n)';        
        y  = ind(:,ones(1,s)) - (idealpoint(:,ones(1,s)) + d1(ones(1,n),:) .* u);
        d2 = (sum(y.^2,1)).^(1/2);
        obj = d1 + theta * d2;
        
    else
        error('individual size must be same as weight size, or equals 1');
    end
end



function mat = vec2mat(vec, m)
    n = length(vec)/m;
    mat = reshape(vec,m,n)';
end


