function ind=genetic_op_sbx(subproblems, index, domain, params)
%GENETICOP function implemented the SBX operation to generate a new
%individual from a subproblems and its neighbours.

%   subproblems: is all the subproblems.
%   index: the index of the subproblem need to handle.
%   domain: the domain of the original multiobjective problem.
%   ind: is an individual structure.    

    eta_c = 30;
    EPS = 1.2e-7;
    
    %The random draw from the neighbours.
    neighbourindex = subproblems(index).neighbour;   
    nsize  = length(neighbourindex);
    parDim = size(domain, 1);
              
    si = neighbourindex(ceil(rand*nsize));
    while si==index
        si=neighbourindex(ceil(rand*nsize));
    end
    
    %retrieve the individuals.
    pop1 = subproblems(index).curpoint.parameter;
    points = [subproblems(si).curpoint];
    pop2 = [points.parameter];
    
    % SBX
    newpoint = zeros(parDim,2);
    if (rand <= 1)
        for i=1:parDim
            if (rand <= 0.5)
                if (abs(pop1(i) - pop2(i)) > EPS)
                    if (pop1(i) < pop2(i))
                        y1 = pop1(i);
                        y2 = pop2(i);
                    else
                        y1 = pop2(i);
                        y2 = pop1(i);
                    end
                    yl = domain(i,1); 
                    yu = domain(i,2); 
                    r = rand;
                    beta = 1.0 + (2.0*(y1-yl)/(y2-y1));
                    alpha = 2.0 - beta^(-(eta_c+1.0));
                    if (r <= (1.0/alpha))
                        betaq = (r*alpha)^(1.0/(eta_c+1.0));
                    else
                        betaq = (1.0 / (2.0-r*alpha))^(1.0/(eta_c + 1.0));
                    end
                    c1 = 0.5*((y1+y2)-betaq*(y2-y1));
                    beta = 1.0 + (2.0*(yu-y2)/(y2-y1));
                    alpha = 2.0 - beta^(-(eta_c + 1.0));
                    if (r <= (1.0/alpha))
                        betaq = (r * alpha)^(1.0 / (eta_c + 1.0));
                    else
                        betaq = (1.0 / (2.0 - r*alpha))^(1.0/(eta_c+1.0));
                    end
                    c2 = 0.5*((y1+y2)+betaq*(y2-y1));
                    if (c1<yl)
                        c1=yl;
                    end
                    if (c2<yl)
                        c2=yl;
                    end
                    if (c1>yu)
                        c1=yu;
                    end
                    if (c2>yu)
                        c2=yu;
                    end
                    if (rand <= 0.5)
                        newpoint(i,1) = c2;
                        newpoint(i,2) = c1;
                    else
                        newpoint(i,1) = c1;
                        newpoint(i,2) = c2;
                    end
                else
                    newpoint(i,1) = pop1(i);
                    newpoint(i,2) = pop2(i);
                end
            else
                newpoint(i,1) = pop1(i);
                newpoint(i,2) = pop2(i);
            end
        end
    else
        for i=1:parDim
            newpoint(i,1) = pop1(i);
            newpoint(i,2) = pop2(i);
        end
    end    
    
    ind = struct('parameter',newpoint(:,2),'objective',[],'estimation',[]);    
    ind = realmutate(ind, domain, 1/parDim);    
end


