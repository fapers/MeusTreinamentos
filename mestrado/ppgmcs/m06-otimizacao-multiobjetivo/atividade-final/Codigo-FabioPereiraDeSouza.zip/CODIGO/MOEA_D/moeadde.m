function pareto = moeadde( mop, varargin)
%MOEAD runs moea/d-de algorithms for the given mop.
%   Detailed explanation goes here
%   The mop must to be minimizing.
%   The parameters of the algorithms can be set through varargin. including
%   popsize: The subproblem's size.
%   niche: the neighboursize, must less then the popsize.
%   iteration: the total iteration of the moead algorithms before finish.
%   method: the decomposition method, the value can be 'ws' or 'te'.
    
    starttime = clock;
    
    %global variable definition.
    global params idealpoint objDim parDim itrCounter nadirpoint;
    
    %set the random generator.
    rng('default');
    rng(sum(100*clock));
    %rand('state',10
    %rand('twister',10);  
    
    %Set the algorithms parameters.
    paramIn = varargin;
    [objDim, parDim, idealpoint, params, subproblems, nadirpoint]=init(mop, paramIn);
        
    itrCounter=1;
    while ~terminate(itrCounter)
        tic;
        subproblems = evolve(subproblems, mop, params);
        
        % plots
%         plotpareto(subproblems,objDim);                
%         plotvec(subproblems,objDim); 
        
%         disp(sprintf('iteration %u finished, time used: %u', itrCounter, toc));
        itrCounter=itrCounter+1;
    end
    pareto=[subproblems.curpoint];
    
    %display the result.    
%     disp(sprintf('total time used %u', etime(clock, starttime)));    
end

function [objDim, parDim, idealp, params, subproblems, nadirp]=init(mop, propertyArgIn)
%Set up the initial setting for the MOEA/D.
    objDim=mop.od;
    parDim=mop.pd;    
    idealp=ones(objDim,1)*inf;
    nadirp=ones(objDim,1)*(-inf);
        
    %the default values for the parameters.
    params.popsize=100;
    params.niche=30;
    params.iteration=100;
    params.dmethod='ts';
    params.F = 0.5;
    params.CR = 0.5;
    
    %handle the parameters, mainly about the popsize
    while length(propertyArgIn)>=2
        prop = propertyArgIn{1};
        val  = propertyArgIn{2};
        propertyArgIn=propertyArgIn(3:end);

        switch prop
            case 'popsize'
                params.popsize=val;
            case 'niche'
                params.niche=val;
            case 'iteration'
                params.iteration=val;
            case 'method'
                params.dmethod=val;
            otherwise
                warning('moea doesnot support the given parameters name');
        end
    end
    
    subproblems = init_weights(params.popsize, params.niche, objDim);    
    params.popsize = length(subproblems);
    
    %initial the subproblem's initital state.
    inds = randompoint(mop, params.popsize);
    [V, INDS] = arrayfun(@evaluate, repmat(mop, size(inds)), inds, 'UniformOutput', 0);
    v = cell2mat(V);
    idealp = min(idealp, min(v,[],2));
    nadirp = max(nadirp, max(v,[],2));
    
    %indcells = mat2cell(INDS, 1, ones(1,params.popsize));
    [subproblems.curpoint] = INDS{:};
    clear inds INDS V indcells;
end
   
function subproblems = evolve(subproblems, mop, params)
    global idealpoint nadirpoint;
    
    for i=1:length(subproblems)
        %new point generation using genetic operations, and evaluate it.
        ind = genetic_op_de(subproblems, i, mop.domain, params);
        [obj,ind] = evaluate(mop, ind);
        
        %update the idealpoint.
        idealpoint = min(idealpoint, obj);
        
        %update the nadirpoint.
        nadirpoint = max(nadirpoint, obj);
        
        %update the neighbours.
        neighbourindex = subproblems(i).neighbour;
        subproblems(neighbourindex)=update(subproblems(neighbourindex),ind,idealpoint,nadirpoint);
        
        clear ind obj neighbourindex;
    end
end

function subproblems = update(subproblems, ind, idealpoint, nadirpoint)
    global params
    
    newobj = subobjective([subproblems.weight], ind.objective, idealpoint, params.dmethod, nadirpoint);
    oops = [subproblems.curpoint];    
    oldobj = subobjective([subproblems.weight], [oops.objective], idealpoint, params.dmethod, nadirpoint);
    
    % As in MOEA/D: "ind" replaces all the worst neighbour solutions
    %C = newobj < oldobj;
    %[subproblems(C).curpoint] = deal(ind); 
    
    % As in MOEA/D-DE: "ind" replaces the "nr" worst random solutions
    nr = 2; % maximum number of solutions replaced by "ind"
    C  = find(newobj < oldobj);
    nC = length(C);
    if (nC > nr)
        idx = randperm(nC);
        C = C(idx(1:nr));
    end
    [subproblems(C).curpoint] = deal(ind);   
    
    clear C newobj oops oldobj;
end

function plotpareto(subproblems,objDim)
    if(objDim>3)
        pareto=[subproblems.curpoint];
        pp=[pareto.objective];
        plot(1:objDim, pp, 'r-');
        set(gca,'xtick',1:objDim);
        xlabel('Objective Number');
        ylabel('Objective Value');
        xlim([1 objDim])
        grid on 
        box on
        pause(0.01);
    else % objDim equals to 2 or 3
        pareto=[subproblems.curpoint];
        pp=[pareto.objective];
        if(objDim==2)
            scatter(pp(1,:),pp(2,:),'ro','MarkerFaceColor','r');
            xlabel('f_1'); ylabel('f_2');
        else
            plot3(pp(1,:),pp(2,:),pp(3,:),'ro','MarkerFaceColor','r')
            xlabel('f_1'); ylabel('f_2'); zlabel('f_3');
        end        
        box on        
    end
end

function plotvec(subproblems,objDim)  
    if(objDim>3), return, end
    w = [subproblems.weight];
    pop = [subproblems.curpoint];
    obj = [pop.objective];
    
    s = size(w,2);
    idealp = min(obj,[],2);
    nadir  = max(obj,[],2);
    d = sqrt(sum((nadir - idealp).^2));
    r = idealp(:,ones(1,s)) + d*w;
    
    hold on
    if(objDim==2)        
        for i=1:s, p=[idealp r(:,i)]; plot(p(1,:),p(2,:),'k--'),end
    else
        for i=1:s, p=[idealp r(:,i)]; plot3(p(1,:),p(2,:),p(3,:),'k--'),end
    end
    hold off
    pause(0.01)
end

function y = terminate(itrcounter)
    global params;
    y = itrcounter>params.iteration;
end