function [POP, FX] = MOEA_D(problema,numOBJ,maxFX)
    
    addpath('..','../data','../results');
    numVAR = limites(problema,numOBJ,0);
    mop = testmop(problema,numVAR,numOBJ);

	metodo = 'te'; %original
%     metodo = 'pbi';
    tamPOP = 100;
    
    pareto = moead( mop, 'popsize', tamPOP, 'niche', 20, 'iteration', maxFX/tamPOP, 'method', metodo);
    FX = [];
    POP = [];
    for i = 1:length(pareto)
        FX = [FX; pareto(i).objective'];
        POP = [POP; pareto(i).parameter'];
    end
end
