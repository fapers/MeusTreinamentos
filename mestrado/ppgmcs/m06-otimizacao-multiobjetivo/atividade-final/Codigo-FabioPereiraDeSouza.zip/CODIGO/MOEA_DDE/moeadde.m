function pareto = moeadde(mop, varargin)
    %global variable definition.
    global params idealpoint objDim parDim itrCounter nadirpoint;
    
    %Set the algorithms parameters.
    paramIn = varargin;
    [objDim, parDim, idealpoint, params, subproblems, nadirpoint] = init(mop, paramIn);
        
    itrCounter=1;
    while ~terminate(itrCounter)
        subproblems = evolve(subproblems, mop, params);
        itrCounter=itrCounter+1;        
%         plotpareto(subproblems,objDim);
%         drawnow();
    end
%     pause;
    pareto=[subproblems.curpoint];    
end

function [objDim, parDim, idealp, params, subproblems, nadirp]=init(mop, propertyArgIn)
%Set up the initial setting for the MOEA/D.
    objDim=mop.od;
    parDim=mop.pd;    
    idealp=ones(objDim,1)*inf;
    nadirp=ones(objDim,1)*(-inf);
        
    %the default values for the parameters.
    params.popsize=100;
    params.niche=30;
    params.iteration=100;
    params.dmethod='ts';
    params.F = 0.5;
    params.CR = 1;
    
    %handle the parameters, mainly about the popsize
    while length(propertyArgIn)>=2
        prop = propertyArgIn{1};
        val  = propertyArgIn{2};
        propertyArgIn=propertyArgIn(3:end);

        switch prop
            case 'popsize'
                params.popsize=val;
            case 'niche'
                params.niche=val;
            case 'iteration'
                params.iteration=val;
            case 'method'
                params.dmethod=val;
            otherwise
                warning('moea doesnot support the given parameters name');
        end
    end
    
    subproblems = init_weights(params.popsize, params.niche, objDim);
    params.popsize = length(subproblems);
    
    %initial the subproblem's initital state.
    inds = randompoint(mop, params.popsize);
    [V, INDS] = arrayfun(@evaluate, repmat(mop, size(inds)), inds, 'UniformOutput', 0);
    v = cell2mat(V);
    idealp = min(idealp, min(v,[],2));
    nadirp = max(nadirp, max(v,[],2));
    
    %indcells = mat2cell(INDS, 1, ones(1,params.popsize));
    [subproblems.curpoint] = INDS{:};
    clear inds INDS V indcells;
end
   
function subproblems = evolve(subproblems, mop, params)
    global idealpoint nadirpoint;
    for i=1:length(subproblems)
%         ind = genetic_op_de(subproblems, i, mop.domain, params); %origin
        ind = genetic_op_sbx(subproblems, i, mop.domain, params);
        [obj,ind] = evaluate(mop, ind);

        idealpoint = min(idealpoint, obj);
        nadirpoint = max(nadirpoint, obj);
        
        %update the neighbours.
        neighbourindex = subproblems(i).neighbour;
        subproblems(neighbourindex) = update(subproblems(neighbourindex),ind,idealpoint,nadirpoint);
        
        clear ind obj neighbourindex;
    end
end

function subproblems = update(subproblems, ind, idealpoint, nadirpoint)
    global params
    
    newobj = subobjective([subproblems.weight], ind.objective, idealpoint, params.dmethod, nadirpoint);
    oops = [subproblems.curpoint];    
    oldobj = subobjective([subproblems.weight], [oops.objective], idealpoint, params.dmethod, nadirpoint);
       
    % As in MOEA/D-DE: "ind" replaces the "nr" worst random solutions
    nr = 2; % maximum number of solutions replaced by "ind"
    C  = find(newobj < oldobj);
    nC = length(C);
    if (nC > nr)
        idx = randperm(nC);
        C = C(idx(1:nr));
    end
    [subproblems(C).curpoint] = deal(ind);   
    
    clear C newobj oops oldobj;
end

function plotpareto(subproblems,objDim)
    if(objDim>3)
        subplot(2,1,1);
        pareto=[subproblems.curpoint];
        pp=[pareto.objective];
        plot(1:objDim, pp, 'r-');
        set(gca,'xtick',1:objDim);
        xlabel('Objective Number');
        ylabel('Objective Value');
        xlim([1 objDim])
        grid on 
        box on
        subplot(2,1,2);
        pp=[pareto.parameter];
        plot(pp, 'r-');        
    else % objDim equals to 2 or 3
        pareto=[subproblems.curpoint];
        pp=[pareto.objective];
        if(objDim==2)
            scatter(pp(1,:),pp(2,:),'ro','MarkerFaceColor','r');
            xlabel('f_1'); ylabel('f_2');
        else
            plot3(pp(1,:),pp(2,:),pp(3,:),'ro','MarkerFaceColor','r')
            xlabel('f_1'); ylabel('f_2'); zlabel('f_3');
        end        
        box on        
    end
end

function y = terminate(itrcounter)
    global params;
    y = itrcounter>params.iteration;
end